
import React from 'react';
import { Dumbbell, Users, Zap, Shield, Trophy, Activity, Target, Flame } from 'lucide-react';
import { Service, Testimonial, FAQ } from './types';

export const GYM_DETAILS = {
  name: "Dragon Fitness",
  tagline: "Delhi's Biggest and Luxury Gym",
  address: "Nihal Vihar, Nangloi, New Delhi, Delhi, 110041",
  googleMapsUrl: "https://www.google.com/maps/dir/?api=1&destination=Dragon+Fitness+Nihal+Vihar+Nangloi+New+Delhi",
  phone: "099994 55153",
  areasServed: "E Block",
  hours: [
    { day: "Monday", time: "5 am – 11 pm" },
    { day: "Tuesday", time: "5 am – 11 pm" },
    { day: "Wednesday", time: "5 am – 11 pm" },
    { day: "Thursday", time: "5 am – 11 pm" },
    { day: "Friday", time: "5 am – 11 pm" },
    { day: "Saturday", time: "5 am – 11 pm" },
    { day: "Sunday", time: "1 pm – 11 pm" }
  ]
};

export const SERVICES: Service[] = [
  {
    id: 1,
    title: "Upper Body Mastery",
    description: "Focus on chest, back, shoulders, and arms with our professional plate-loaded machines and free weights.",
    icon: "Dumbbell",
    image: "https://images.unsplash.com/photo-1581009146145-b5ef03a94e77?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 2,
    title: "Lower Body Strength",
    description: "Comprehensive leg press, hack squats, and deadlift platforms to build powerful quads, glutes, and hamstrings.",
    icon: "Target",
    image: "https://images.unsplash.com/photo-1574680178050-55c6a6a96e0a?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 3,
    title: "Full Body Transformation",
    description: "High-intensity circuits and compound movements designed for complete physical evolution.",
    icon: "Flame",
    image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 4,
    title: "Core & Conditioning",
    description: "Stabilize your foundation with dedicated core stations and functional training equipment.",
    icon: "Zap",
    image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&q=80&w=800"
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: "Vikram S.",
    role: "Skinny to Fit Journey",
    content: "I started here as a very skinny guy with zero confidence. The trainers and the massive space made me feel welcome. Gained 12kg of muscle in 6 months!",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: 2,
    name: "Arjun Khanna",
    role: "Professional Bodybuilder",
    content: "Dragon Fitness has the best lower body equipment in Delhi. The leg press here is beastly. Perfect for advanced athletes looking for a hardcore pump.",
    avatar: "https://images.unsplash.com/photo-1534367507873-d2d7e24c797f?auto=format&fit=crop&q=80&w=150"
  },
  {
    id: 3,
    name: "Anirudh Singh",
    role: "Elite Member",
    content: "Fantastic gym huge space for workout supporting staff and owner. Best luxury experience in Nangloi.",
    avatar: "https://i.pravatar.cc/150?u=anirudh"
  }
];

export const FAQS: FAQ[] = [
  {
    id: 1,
    question: "How do I start my transformation?",
    answer: "Simply click 'Enroll Now' to call us, or visit our Nihal Vihar facility. We'll provide a free walkthrough and body assessment."
  },
  {
    id: 2,
    question: "Is there enough equipment for legs?",
    answer: "Yes! We have a dedicated lower-body zone with multiple squat racks, leg presses, and specialized machines for hamstrings and calves."
  },
  {
    id: 3,
    question: "Do you offer professional guidance?",
    answer: "Our trainers are certified professionals who specialize in both beginner 'skinny-to-fit' programs and advanced bodybuilding prep."
  }
];
