
import React, { useState, useEffect, useCallback } from 'react';
import { 
  Dumbbell, 
  Menu, 
  X, 
  Phone, 
  MapPin, 
  ChevronDown, 
  Sun, 
  Moon,
  ArrowRight,
  CheckCircle2,
  Users,
  Zap,
  Flame,
  Target
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { GYM_DETAILS, SERVICES, TESTIMONIALS, FAQS } from './constants';

const App: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);

      const sections = ['home', 'services', 'about', 'testimonials', 'faq'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const scrollToSection = useCallback((e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    
    if (element) {
      const headerOffset = 90;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
      
      setIsMenuOpen(false);
    }
  }, []);

  const getIcon = (name: string) => {
    const iconProps = { className: "w-8 h-8" };
    switch (name) {
      case 'Dumbbell': return <Dumbbell {...iconProps} />;
      case 'Users': return <Users {...iconProps} />;
      case 'Zap': return <Zap {...iconProps} />;
      case 'Flame': return <Flame {...iconProps} />;
      case 'Target': return <Target {...iconProps} />;
      default: return <Dumbbell {...iconProps} />;
    }
  };

  const navLinks = [
    { name: 'HOME', href: '#home', id: 'home' },
    { name: 'SERVICES', href: '#services', id: 'services' },
    { name: 'ABOUT', href: '#about', id: 'about' },
    { name: 'TESTIMONIALS', href: '#testimonials', id: 'testimonials' },
    { name: 'FAQ', href: '#faq', id: 'faq' }
  ];

  const phoneLink = `tel:${GYM_DETAILS.phone.replace(/\s+/g, '')}`;

  return (
    <div className={`${isDarkMode ? 'bg-zinc-950 text-white' : 'bg-zinc-50 text-zinc-900'} min-h-screen transition-colors duration-500 selection:bg-red-500 selection:text-white`}>
      {/* Navigation */}
      <header 
        className={`fixed top-0 w-full z-50 transition-all duration-500 ${
          scrolled ? 'glass py-3 shadow-2xl' : 'bg-transparent py-6'
        }`}
      >
        <div className="container mx-auto px-6 flex justify-between items-center relative">
          <motion.a 
            href="#home" 
            whileHover={{ scale: 1.05 }}
            onClick={(e) => scrollToSection(e, '#home')}
            className="flex items-center gap-2 group z-10"
          >
            <div className="bg-red-600 p-2 rounded-lg shadow-lg">
              <Dumbbell className="text-white w-6 h-6" />
            </div>
            <span className="text-xl font-black tracking-tighter uppercase italic text-white">
              DRAGON <span className="text-red-500">FITNESS</span>
            </span>
          </motion.a>

          <nav className="hidden md:flex items-center gap-6 lg:gap-8 absolute left-1/2 -translate-x-1/2 text-[14px] font-black uppercase tracking-tighter">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                onClick={(e) => scrollToSection(e, link.href)}
                className={`transition-all duration-300 drop-shadow-lg relative group ${
                  activeSection === link.id ? 'text-red-500' : 'text-white hover:text-red-400'
                }`}
              >
                {link.name}
                <motion.span 
                  initial={false}
                  animate={{ width: activeSection === link.id ? '100%' : '0%' }}
                  className="absolute -bottom-1 left-0 h-0.5 bg-red-600"
                />
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-4 z-10">
            <button 
              onClick={toggleDarkMode}
              className="hidden sm:flex p-2 rounded-full hover:bg-white/10 transition-colors text-white"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <motion.a 
              href={phoneLink} 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-red-600 hover:bg-red-700 px-6 py-4 rounded-3xl text-white text-xs font-black uppercase tracking-tighter shadow-xl flex flex-col items-center justify-center leading-tight min-w-[120px]"
            >
              <span>ENROLL</span>
              <span>NOW</span>
            </motion.a>
            <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="md:hidden glass absolute top-full left-0 w-full overflow-hidden"
            >
              <nav className="flex flex-col p-6 gap-6 font-bold uppercase tracking-widest text-center">
                {navLinks.map((link) => (
                  <a 
                    key={link.name} 
                    href={link.href} 
                    onClick={(e) => scrollToSection(e, link.href)}
                    className={`text-white hover:text-red-500 transition-colors ${activeSection === link.id ? 'text-red-500' : ''}`}
                  >
                    {link.name}
                  </a>
                ))}
                <a href={phoneLink} className="bg-red-600 text-white py-4 rounded-xl font-black">ENROLL NOW</a>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1593079831268-3381b0db4a77?auto=format&fit=crop&q=80&w=2000" 
            className="w-full h-full object-cover grayscale contrast-125 opacity-40"
            alt="Gym Atmosphere"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-zinc-950/60 via-zinc-950/40 to-zinc-950"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10 mt-12">
          <motion.div 
            initial={{ x: -100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-4xl"
          >
            <h1 className="text-[80px] md:text-[140px] font-black uppercase italic leading-[0.8] tracking-tighter mb-4 text-white drop-shadow-2xl">
              PUSH <br />
              <span className="bg-orange-500 px-4 py-2 inline-block -rotate-1 shadow-2xl">BEYOND</span>
            </h1>
            <p className="text-xl md:text-2xl text-white max-w-2xl mb-12 font-bold leading-relaxed drop-shadow-md">
              Join Dragon Fitness today. Experience 20,000+ sq. ft. of elite gym workout space with world-class equipment and professional guidance.
            </p>
            <div className="flex flex-col sm:flex-row gap-6">
              <motion.a 
                href={phoneLink} 
                whileHover={{ scale: 1.05, x: 10 }}
                className="bg-red-600 hover:bg-red-700 text-white px-12 py-6 rounded-xl font-black uppercase tracking-widest transition-all flex items-center justify-center gap-4 group shadow-2xl shadow-red-600/40 text-xl"
              >
                ENROLL NOW <ArrowRight className="group-hover:translate-x-2 transition-transform" />
              </motion.a>
              <motion.a 
                href="#about" 
                whileHover={{ scale: 1.05 }}
                onClick={(e) => scrollToSection(e, '#about')}
                className="bg-zinc-800 hover:bg-zinc-700 border border-white/10 px-12 py-6 rounded-xl font-black uppercase tracking-widest transition-all text-center text-xl text-white"
              >
                LEARN MORE
              </motion.a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className={`py-24 scroll-mt-20 transition-colors duration-500 ${isDarkMode ? 'bg-zinc-950' : 'bg-zinc-100'}`}>
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-5xl md:text-7xl font-black uppercase italic mb-6">GYM SERVICES</h2>
            <p className={`${isDarkMode ? 'text-zinc-400' : 'text-zinc-600'} font-black uppercase tracking-widest text-lg`}>Comprehensive training for upper and lower body excellence.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {SERVICES.map((service) => (
              <motion.div 
                key={service.id} 
                whileHover="hover"
                initial="initial"
                className={`group relative h-[500px] overflow-hidden rounded-3xl border-2 transition-all duration-500 ${isDarkMode ? 'border-white/5 bg-zinc-900 hover:border-red-600 shadow-2xl shadow-red-600/5' : 'border-zinc-200 bg-white hover:border-red-600 shadow-xl'}`}
              >
                <img 
                  src={service.image} 
                  alt={service.title} 
                  className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-100 group-hover:scale-105 transition-all duration-1000"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${isDarkMode ? 'from-zinc-950 via-zinc-950/60' : 'from-zinc-50/80'} to-transparent`}></div>
                <div className="absolute bottom-0 left-0 p-8 w-full z-10">
                  <motion.div 
                    variants={{
                      hover: { rotate: 12, scale: 1.1, backgroundColor: "#ef4444" },
                      initial: { rotate: 0, scale: 1, backgroundColor: "#dc2626" }
                    }}
                    transition={{ type: "spring", stiffness: 300 }}
                    className="w-16 h-16 rounded-2xl flex items-center justify-center text-white mb-6"
                  >
                    {getIcon(service.icon)}
                  </motion.div>
                  <h3 className="text-3xl font-black uppercase italic mb-4 leading-none text-white">{service.title}</h3>
                  <p className="text-white text-sm font-black uppercase leading-relaxed opacity-0 group-hover:opacity-100 transition-all transform translate-y-4 group-hover:translate-y-0">
                    {service.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 overflow-hidden relative scroll-mt-20">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-16 items-center">
            <div className="lg:w-1/2 relative">
              <div className="grid grid-cols-2 gap-6">
                <motion.img 
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=800" 
                  className="rounded-3xl h-[450px] object-cover mt-12 shadow-2xl border-4 border-red-600/20" 
                  alt="Training" 
                />
                <motion.img 
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.2 }}
                  src="https://images.unsplash.com/photo-1540497077202-7c8a3999166f?auto=format&fit=crop&q=80&w=800" 
                  className="rounded-3xl h-[450px] object-cover shadow-2xl border-4 border-red-600/20" 
                  alt="Facility" 
                />
              </div>
              <motion.div 
                initial={{ rotate: 0, scale: 0.5, opacity: 0 }}
                whileInView={{ rotate: 12, scale: 1, opacity: 1 }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-red-600 text-white p-10 rounded-full shadow-2xl text-center hidden sm:block border-8 border-zinc-950"
              >
                <p className="text-6xl font-black italic tracking-tighter uppercase leading-none">20K+</p>
                <p className="text-sm font-black uppercase tracking-widest">SQ FT AREA</p>
              </motion.div>
            </div>
            
            <div className="lg:w-1/2">
              <h2 className="text-6xl md:text-8xl font-black uppercase italic mb-8 leading-[0.85]">
                DRAGON <br />
                <span className="text-red-600">FITNESS</span>
              </h2>
              <div className={`space-y-8 ${isDarkMode ? 'text-zinc-300' : 'text-zinc-800'} text-xl font-black uppercase italic leading-tight`}>
                <p className="border-l-8 border-red-600 pl-6">
                  Delhi's Biggest and Luxury Gym located in Nihal Vihar, Nangloi. 
                </p>
                <p>
                  We focus on serious results. Whether you want to gain muscle like our bodybuilders or undergo a skinny-to-fit transformation, our floor has the tools you need.
                </p>
                <ul className="grid grid-cols-1 gap-4">
                  {[
                    "ELITE UPPER BODY MACHINES",
                    "HARDCORE LOWER BODY ZONE",
                    "PRO-BODYBUILDING PLATFORMS"
                  ].map((item, idx) => (
                    <motion.li 
                      key={item}
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="flex items-center gap-4"
                    >
                      <motion.div
                        whileInView={{ scale: [1, 1.2, 1] }}
                        transition={{ repeat: Infinity, duration: 2 }}
                      >
                        <CheckCircle2 className="text-red-600 w-8 h-8 shrink-0" />
                      </motion.div>
                      {item}
                    </motion.li>
                  ))}
                </ul>
                
                <div className="pt-8 grid sm:grid-cols-2 gap-8">
                   <motion.a 
                     href={phoneLink} 
                     whileHover={{ y: -5 }}
                     className="flex items-center gap-4 bg-zinc-900 p-6 rounded-2xl hover:bg-zinc-800 transition-all border border-white/5"
                   >
                      <motion.div 
                        whileHover={{ rotate: [0, -10, 10, -10, 0] }}
                        className="bg-red-600 p-4 rounded-xl text-white"
                      >
                        <Phone />
                      </motion.div>
                      <div>
                        <p className="font-black text-white">{GYM_DETAILS.phone}</p>
                        <p className="text-xs text-red-500 uppercase font-black">CALL US NOW</p>
                      </div>
                   </motion.a>
                   <motion.a 
                     href={GYM_DETAILS.googleMapsUrl} 
                     target="_blank" 
                     rel="noopener noreferrer" 
                     whileHover={{ y: -5 }}
                     className="flex items-center gap-4 bg-zinc-900 p-6 rounded-2xl hover:bg-zinc-800 transition-all border border-white/5"
                   >
                      <motion.div 
                        whileHover={{ scale: 1.2, y: -2 }}
                        className="bg-zinc-800 p-4 rounded-xl text-white"
                      >
                        <MapPin />
                      </motion.div>
                      <div>
                        <p className="font-black text-white uppercase leading-none">NIHAL VIHAR</p>
                        <p className="text-xs text-red-500 uppercase font-black">GET DIRECTIONS</p>
                      </div>
                   </motion.a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className={`py-24 scroll-mt-20 transition-colors duration-500 ${isDarkMode ? 'bg-zinc-900/50' : 'bg-zinc-200'}`}>
        <div className="container mx-auto px-6">
          <h2 className="text-6xl md:text-8xl font-black uppercase italic text-center mb-16 leading-none">THE <span className="text-red-600">EVOLUTION</span></h2>
          <div className="grid md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((t, idx) => (
              <motion.div 
                key={t.id} 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className={`p-10 rounded-[40px] border-4 transition-all flex flex-col justify-between group ${isDarkMode ? 'bg-zinc-950 border-white/5 hover:border-red-600' : 'bg-white border-zinc-300 hover:border-red-600 shadow-2xl'}`}
              >
                <div className="mb-10">
                  <div className="flex gap-2 mb-8">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <motion.div
                        key={s}
                        whileInView={{ scale: [1, 1.3, 1] }}
                        transition={{ repeat: Infinity, duration: 1.5, delay: s * 0.2 }}
                      >
                        <Flame className="w-6 h-6 fill-red-600 text-red-600" />
                      </motion.div>
                    ))}
                  </div>
                  <p className={`text-2xl font-black italic uppercase leading-tight ${isDarkMode ? 'text-white' : 'text-zinc-900'}`}>"{t.content}"</p>
                </div>
                <div className="flex items-center gap-6">
                  <div className="relative">
                    <img src={t.avatar} className="w-20 h-20 rounded-2xl object-cover border-4 border-red-600" alt={t.name} />
                    <motion.div 
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ repeat: Infinity, duration: 1 }}
                      className="absolute -bottom-2 -right-2 bg-red-600 p-1.5 rounded-lg text-white shadow-lg"
                    >
                      <Zap size={12} fill="white" />
                    </motion.div>
                  </div>
                  <div>
                    <h4 className={`font-black uppercase text-xl italic tracking-tighter ${isDarkMode ? 'text-white' : 'text-zinc-900'}`}>{t.name}</h4>
                    <p className="text-red-500 text-sm font-black uppercase italic">{t.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-24 bg-zinc-950 scroll-mt-20">
        <div className="container mx-auto px-6 max-w-5xl">
          <h2 className="text-5xl md:text-8xl font-black uppercase italic text-center mb-16">ANY <span className="text-red-600">DOUBTS?</span></h2>
          <div className="grid gap-6">
            {FAQS.map((faq) => (
              <div 
                key={faq.id} 
                className={`border-4 rounded-3xl transition-all ${
                  activeFaq === faq.id 
                  ? 'border-red-600 bg-red-600/5' 
                  : 'border-white/5'
                }`}
              >
                <button 
                  onClick={() => setActiveFaq(activeFaq === faq.id ? null : faq.id)}
                  className="w-full flex items-center justify-between p-8 text-left"
                >
                  <span className="font-black uppercase italic tracking-wider text-2xl">0{faq.id}. {faq.question}</span>
                  <motion.div 
                    animate={{ rotate: activeFaq === faq.id ? 180 : 0 }}
                    className={`p-2 rounded-xl transition-all ${activeFaq === faq.id ? 'bg-red-600' : 'bg-zinc-800'}`}
                  >
                    <ChevronDown className="text-white" />
                  </motion.div>
                </button>
                <AnimatePresence>
                  {activeFaq === faq.id && (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="p-8 pt-0 font-black uppercase italic text-zinc-400 text-xl border-t-4 border-white/5">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Map Integration */}
      <section className="h-[500px] w-full relative">
        <iframe 
          title="Gym Location"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3500.518627063467!2d77.062085!3d28.674144!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d040000000001%3A0x0!2zRHJhZ29uIEZpdG5lc3M!5e0!3m2!1sen!2sin!4v1711234567890!5m2!1sen!2sin" 
          width="100%" 
          height="100%" 
          style={{ border: 0, filter: isDarkMode ? 'invert(90%) hue-rotate(180deg) grayscale(100%)' : 'none' }} 
          allowFullScreen={true} 
          loading="lazy"
        ></iframe>
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-zinc-950 via-transparent to-zinc-950 opacity-40"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          <motion.a 
            href={GYM_DETAILS.googleMapsUrl} 
            target="_blank" 
            rel="noopener noreferrer" 
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="pointer-events-auto bg-red-600 text-white px-10 py-5 rounded-full font-black uppercase italic tracking-widest shadow-2xl flex items-center gap-4 transition-transform"
          >
            VIEW ON MAP <MapPin />
          </motion.a>
        </div>
      </section>

      {/* Footer */}
      <footer className="pt-24 pb-12 bg-zinc-950 border-t-8 border-red-600">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-3 gap-20 mb-24">
            <div>
              <div className="flex items-center gap-3 mb-10">
                <div className="bg-red-600 p-3 rounded-2xl shadow-xl">
                  <Dumbbell className="text-white w-8 h-8" />
                </div>
                <span className="text-4xl font-black tracking-tighter uppercase italic text-white">
                  DRAGON <span className="text-red-500">FITNESS</span>
                </span>
              </div>
              <p className="mb-10 text-xl font-black uppercase italic text-zinc-500 leading-tight">
                DELHI'S BIGGEST LUXURY GYM. <br /> NIHAL VIHAR, NANGLOI.
              </p>
              <a href={phoneLink} className="bg-red-600 text-white px-10 py-4 rounded-2xl font-black uppercase italic tracking-widest inline-block hover:bg-red-700 transition-all text-xl shadow-xl">
                CALL: {GYM_DETAILS.phone}
              </a>
            </div>

            <div className="grid grid-cols-2 gap-10">
              <div>
                <h4 className="font-black uppercase italic tracking-widest text-lg mb-8 text-red-600">TIMINGS</h4>
                <ul className="space-y-4 text-sm font-black uppercase italic text-zinc-400">
                  {GYM_DETAILS.hours.map((h, i) => (
                    <li key={i} className="flex justify-between border-b border-white/5 pb-2">
                      <span>{h.day}</span>
                      <span className="text-white">{h.time}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="font-black uppercase italic tracking-widest text-lg mb-8 text-red-600">NAVIGATE</h4>
                <ul className="space-y-6 text-xl font-black uppercase italic tracking-tighter text-zinc-400">
                  {navLinks.map(link => (
                    <li key={link.name}>
                      <a 
                        href={link.href} 
                        onClick={(e) => scrollToSection(e, link.href)}
                        className={`transition-colors duration-300 ${activeSection === link.id ? 'text-red-500' : 'hover:text-red-500'}`}
                      >
                        {link.name}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div>
              <h4 className="font-black uppercase italic tracking-widest text-lg mb-8 text-red-600">CONTACT</h4>
              <div className="space-y-8">
                <a href={GYM_DETAILS.googleMapsUrl} target="_blank" rel="noopener noreferrer" className="flex items-start gap-6 group">
                  <motion.div 
                    whileHover={{ scale: 1.1, backgroundColor: "#dc2626" }}
                    className="bg-zinc-900 p-4 rounded-2xl transition-colors"
                  >
                    <MapPin className="text-white" />
                  </motion.div>
                  <p className="text-xl font-black uppercase italic text-zinc-400 leading-tight group-hover:text-white transition-colors">{GYM_DETAILS.address}</p>
                </a>
                <div className="p-8 rounded-[32px] bg-red-600/10 border-4 border-red-600/20">
                  <p className="text-red-500 text-sm font-black uppercase italic tracking-widest mb-2">AREAS SERVED</p>
                  <p className="text-2xl font-black uppercase italic text-white">{GYM_DETAILS.areasServed}, NIHAL VIHAR</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border-t-4 border-white/5 pt-12 text-center text-zinc-600 text-sm font-black uppercase italic tracking-widest">
            <p>&copy; {new Date().getFullYear()} DRAGON FITNESS. DESIGNED FOR PERFORMANCE.</p>
          </div>
        </div>
      </footer>

      {/* Floating CTA */}
      <motion.div 
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        className="fixed bottom-10 right-10 z-50"
      >
        <motion.a 
          href={phoneLink} 
          animate={{ 
            boxShadow: [
              "0 0 0 0px rgba(239, 68, 68, 0.4)",
              "0 0 0 20px rgba(239, 68, 68, 0)",
              "0 0 0 0px rgba(239, 68, 68, 0)"
            ] 
          }}
          transition={{ repeat: Infinity, duration: 2 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="w-20 h-20 bg-red-600 rounded-3xl flex items-center justify-center border-4 border-white/20 shadow-2xl"
          aria-label="Call Dragon Fitness"
        >
          <Phone className="text-white w-10 h-10" fill="currentColor" />
        </motion.a>
      </motion.div>
    </div>
  );
};

export default App;
